        <section class="contact">
            <h2>Contact</h2>
            <ul class="social-media">
                <li>
                    <a href="https://www.facebook.com/damian.kokot.18" target="_blank" class="icon-link">
                        <i class="fab fa-facebook-square"></i>
                    </a>
                </li>
                <li>
                    <a href="https://github.com/damianKokot" target="_blank" class="icon-link">
                        <i class="fab fa-github-square"></i>
                    </a>
                </li>
                <li>
                    <a href="https://www.linkedin.com/in/damian-kokot-18bb841b0" target="_blank" class="icon-link">
                        <i class="fab fa-linkedin"></i>
                    </a>
                </li>
            </ul>
        </section>