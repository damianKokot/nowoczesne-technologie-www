<?php include 'common/session.php' ?>

<!DOCTYPE html>
<html lang="pl-PL">

<head>
    <title><?php echo $currentpage;?></title>
    <link rel="stylesheet" href="./assets/main.css">
    <link href="https://fonts.googleapis.com/css?family=Poiret+One&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.0-2/css/all.min.css">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta charset="UTF-8">

    <noscript><style> .menu-toggler { display: none } </style></noscript>
</head>
