    <header>
        <img src="./assets/CV_img.jpg" alt="portfolio-image" />
        <div id="name">
            <h1>Damian Kokot</h1>
            <h2>The Web Backend Developer</h2>
        </div>
    </header>